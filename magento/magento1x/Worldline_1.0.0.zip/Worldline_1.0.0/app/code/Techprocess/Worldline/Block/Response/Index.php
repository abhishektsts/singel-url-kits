<?php


namespace Techprocess\Worldline\Block\Response;


class Index extends \Magento\Framework\View\Element\Template
{

    
}
