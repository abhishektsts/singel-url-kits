<?php


namespace Techprocess\Worldline\Block\Redirect;




class Index extends \Magento\Framework\View\Element\Template
{

    
}