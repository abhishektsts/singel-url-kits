<?php

/**
 * Worldline Data helper
 **/

class Worldline_Worldline_Helper_Data extends Mage_Core_Helper_Abstract
{
}
