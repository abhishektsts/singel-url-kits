<?php


namespace Worldline\Worldline\Block\Redirect;




class Index extends \Magento\Framework\View\Element\Template
{

    
}