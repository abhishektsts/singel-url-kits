<?php
// Text
$_['text_title'] = 'Credit card / Debit card - Worldline';
