<?php
// Text
$_['text_title'] = 'Cards / UPI / Netbanking / Wallets';