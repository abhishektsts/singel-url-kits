<?php
// Heading
$_['heading_title'] = 'Error Log';

// Text
$_['text_success']  = 'Success: You have successfully cleared your error log!';
?>